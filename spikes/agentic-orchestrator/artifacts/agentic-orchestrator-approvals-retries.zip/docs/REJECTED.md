# Rejected ideas (for now)

- **Streaming logs through DB**: DB stores pointers + summaries; raw logs stay on disk for now.
- **Full Surreal graph edges**: We model dependencies as arrays of stage IDs for simpler scheduling. (Edges can be added later.)
- **Complex retry policies**: Retries are intentionally not automated in v0. Failures stop downstream work.
- **Secrets injection**: Out of scope until a policy + audit mechanism exists.
- **Cross-host artifact storage**: No object-store integration yet.
