# Use cases and scenario coverage

The following scenarios guided the MVP:

1. **Single-stage lint**: One exec_block runs `cargo fmt --check`.
2. **Build then test**: Two stages with dependency edge.
3. **Fan-out tests**: Build → (unit, integration, clippy) in parallel.
4. **Fan-in**: Multiple prerequisite stages gate a final packaging stage.
5. **Gate approval**: A stage enters `needs_human` and is unblocked by `/approve`.
6. **Gate rejection**: A stage is rejected and the run becomes `failed`.
7. **Emit stage**: Emit a JSON summary artifact after test completion (v0 is placeholder).
8. **At-least-once**: Agent crashes mid-job; lease expires and another agent reclaims.
9. **Idempotent complete**: Agent retries HTTP POST /complete; daemon ignores duplicates.
10. **Non-zero exit code**: Command fails; stage retries if `max_attempts > 1`.
11. **Retries exhausted**: Stage reaches `max_attempts` and is marked failed; downstream not scheduled.
12. **Unsafe command**: Exec contains `sudo rm -rf /`; rejected in validation.
13. **Path escape attempt**: Workdir `../../..`; rejected by agent containment check.
14. **Missing node in edge**: DAG validation rejects unknown node references.
15. **Cycle in DAG**: Validation rejects cycles.
16. **Workflow version reuse**: Same workflow spec yields same hash and reuses workflow_version.
17. **Different workflow versions**: Any change in spec creates a new workflow_version.
18. **Multiple agents**: Two agents claim from one project; load spreads by job queue.
19. **DB restart**: Daemon restarts; scheduler resumes pending stages/jobs from DB.
20. **Workspace mode**: If `jj` installed, agent creates a workspace directory per stage.
21. **Artifact upload**: Agent uploads a ZIP bundle of artifacts to the daemon (cross-host friendly).

Gaps (intentional for v0):
- no secrets management
- no object-store integration (daemon stores bundles on local disk)
- no complex backoff policies
