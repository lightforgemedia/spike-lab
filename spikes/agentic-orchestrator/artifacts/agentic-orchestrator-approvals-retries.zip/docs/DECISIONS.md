# Decisions (v0)

1. **Embedded-first DB**: Use SurrealDB embedded via SurrealKV for a single-node "project start" experience.
2. **Workflow = versioned DAG**: Store workflow definitions in DB and version by stable content hash.
3. **Run = materialized stage-runs**: A run materializes stage instances so scheduling/visibility is stable even if the workflow later evolves.
4. **Agent leases**: Jobs are claimed with a lease token + expiry to tolerate agent crashes (at-least-once delivery).
5. **Exec blocks produce artifacts**: Every command writes stdout/stderr to a unique path; DB stores pointers + summaries.
6. **Two-stage validation**: Daemon performs schema validation; agent performs workdir containment checks.
7. **KISS scheduler**: Periodic tick computes readiness in-memory from stage graph and writes minimal updates.
8. **IDs are ULIDs**: Human-friendly, time-sortable identifiers for runs, stages, jobs, versions.
9. **Fallback VCS**: If `jj` isn't available, agent falls back to running directly in the project directory.
10. **Idempotent complete**: Job completion is safe to call more than once (first write wins).
