use crate::state::AppState;
use orchestrator_core::{now_ms, JobRow, JobStatus, RunRow, RunStatus, StageKind, StageRunRow, StageStatus};
use tokio::sync::oneshot;
use tracing::{debug, info, warn};
use ulid::Ulid;

use std::sync::Arc;
use std::time::Duration;

/// Simple periodic scheduler:
/// - Finds runs not terminal
/// - For each run, loads all stages and computes readiness
/// - Queues jobs for ready exec_block stages
/// - Marks noop/emit stages as succeeded
/// - Marks gate stages as succeeded or needs_human depending on config
/// - Reconciles run status
pub async fn scheduler_loop(state: Arc<AppState>, mut stop: oneshot::Receiver<()>) {
    let tick = Duration::from_millis(state.cfg.scheduler_tick_ms);
    loop {
        tokio::select! {
            _ = tokio::time::sleep(tick) => {
                if let Err(e) = tick_once(&state).await {
                    warn!(error=?e, "scheduler tick failed");
                }
            }
            _ = &mut stop => {
                info!("scheduler stopping");
                return;
            }
        }
    }
}

async fn tick_once(state: &Arc<AppState>) -> anyhow::Result<()> {
    let runs: Vec<RunRow> = state.db
        .query(r#"
            SELECT * FROM run
            WHERE status != "succeeded" AND status != "failed"
            ORDER BY created_at_ms;
        "#)
        .await?
        .take(0)?;

    for run in runs {
        reconcile_run(state, &run).await?;
    }
    Ok(())
}

async fn reconcile_run(state: &Arc<AppState>, run: &RunRow) -> anyhow::Result<()> {
    let mut stages: Vec<StageRunRow> = state.db
        .query("SELECT * FROM stage_run WHERE run_id = $run_id ORDER BY created_at_ms;")
        .bind(("run_id", run.id.clone()))
        .await?
        .take(0)?;

    // Build status map
    let mut status: std::collections::HashMap<String, StageStatus> = std::collections::HashMap::new();
    for s in &stages {
        status.insert(s.id.clone(), s.status);
    }

    let now = now_ms();

    // Process ready stages
    for s in &stages {
        if s.status != StageStatus::Pending {
            continue;
        }
        let ready = s.deps.iter().all(|d| status.get(d) == Some(&StageStatus::Succeeded));
        if !ready {
            continue;
        }

        match s.kind {
            StageKind::ExecBlock => {
                // ensure no active job exists
                let existing: Vec<JobRow> = state.db
                    .query(r#"
                        SELECT * FROM job WHERE stage_id = $stage_id
                        AND (status = "queued" OR status = "running")
                        LIMIT 1;
                    "#)
                    .bind(("stage_id", s.id.clone()))
                    .await?
                    .take(0)?;
                if existing.is_empty() {
                    let attempt = s.attempts_used.saturating_add(1);
                    if attempt > s.max_attempts {
                        let _updated: Option<StageRunRow> = state.db
                            .update(("stage_run", s.id.as_str()))
                            .merge(serde_json::json!({"status": StageStatus::Failed, "updated_at_ms": now}))
                            .await?;
                        status.insert(s.id.clone(), StageStatus::Failed);
                        continue;
                    }

                    let job_id = Ulid::new().to_string();
                    let job = JobRow {
                        id: job_id.clone(),
                        stage_id: s.id.clone(),
                        status: JobStatus::Queued,
                        lease_owner: None,
                        lease_token: None,
                        lease_expires_at_ms: None,
                        attempt,
                        created_at_ms: now,
                        updated_at_ms: now,
                    };
                    let _created: Option<JobRow> = state.db
                        .create(("job", job_id.as_str()))
                        .content(job)
                        .await?;
                    debug!(run_id=%run.id, stage_id=%s.id, job_id=%job_id, attempt, "queued job");

                    let _updated: Option<StageRunRow> = state.db.update(("stage_run", s.id.as_str()))
                        .merge(serde_json::json!({"status": StageStatus::Queued, "updated_at_ms": now}))
                        .await?;
                    status.insert(s.id.clone(), StageStatus::Queued);
                }
            }
            StageKind::Gate => {
                let requires = s.config.as_ref()
                    .and_then(|v| v.get("requires_approval"))
                    .and_then(|v| v.as_bool())
                    .unwrap_or(false);
                let new_status = if requires { StageStatus::NeedsHuman } else { StageStatus::Succeeded };

                let _updated: Option<StageRunRow> = state.db.update(("stage_run", s.id.as_str()))
                    .merge(serde_json::json!({"status": new_status, "updated_at_ms": now}))
                    .await?;
                status.insert(s.id.clone(), new_status);
            }
            StageKind::Emit | StageKind::Noop => {
                let _updated: Option<StageRunRow> = state.db.update(("stage_run", s.id.as_str()))
                    .merge(serde_json::json!({"status": StageStatus::Succeeded, "updated_at_ms": now}))
                    .await?;
                status.insert(s.id.clone(), StageStatus::Succeeded);
            }
        }
    }

    // Recompute run status
    stages = state.db
        .query("SELECT * FROM stage_run WHERE run_id = $run_id;")
        .bind(("run_id", run.id.clone()))
        .await?
        .take(0)?;

    let any_failed = stages.iter().any(|s| s.status == StageStatus::Failed);
    let all_succeeded = !stages.is_empty() && stages.iter().all(|s| s.status == StageStatus::Succeeded);
    let any_active = stages.iter().any(|s| matches!(s.status, StageStatus::Queued | StageStatus::Running | StageStatus::Pending | StageStatus::NeedsHuman));

    let new_status = if any_failed {
        RunStatus::Failed
    } else if all_succeeded {
        RunStatus::Succeeded
    } else if any_active {
        RunStatus::Running
    } else {
        RunStatus::Running
    };

    if new_status != run.status {
        let _ = state.db.update(("run", run.id.as_str()))
            .merge(serde_json::json!({"status": new_status, "updated_at_ms": now}))
            .await?;
        info!(run_id=%run.id, ?new_status, "run status updated");
    }

    Ok(())
}
