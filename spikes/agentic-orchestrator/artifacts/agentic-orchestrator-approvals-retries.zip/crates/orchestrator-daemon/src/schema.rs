/// Embedded schema applied at daemon startup.
pub const SCHEMA: &str = include_str!("../../../docs/SCHEMA.surql");
