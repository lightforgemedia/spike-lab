# Rejected or deferred options

## External message queue (Kafka/NATS/Rabbit)

Rejected for v0 to keep operational footprint minimal. SurrealDB stores queue state.

## Full jj integration (revision-aware workflows)

We do *minimal* jj automation today (init + per-run workspaces). What's still deferred:

- passing revision ids between stages (so different agents can work on the same run safely)
- auto-committing at stage boundaries
- conflict resolution policies / merge automation

## Streaming logs into DB

Rejected for v0: bundles are simpler, immutable, and cheaper.

## Perfect command safety

Not attempted. This requires OS sandboxing. Validation here is guardrails, not a sandbox.
