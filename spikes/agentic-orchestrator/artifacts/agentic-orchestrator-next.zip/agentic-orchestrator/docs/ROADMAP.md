# Roadmap

- Workspace isolation per agent/run (jj-based colocated workspaces) ✅ (v0.1)
- DAG parallelism (multiple runnable stages at once)
- Artifact pushing (S3-compatible) and signed manifests
- Secret injection (sealed secrets + per-stage scopes)
- Pluggable executors (local ✅, slurm ✅, container runner, remote runner)
- Policy language for command allow/deny
