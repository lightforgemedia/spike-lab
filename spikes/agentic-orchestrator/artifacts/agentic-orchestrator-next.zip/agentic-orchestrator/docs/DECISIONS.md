# Decisions

## Embedded SurrealDB

Selected SurrealDB embedded via `surrealkv://...` because it can store documents and graph edges in one engine.

## Graph-first runtime model

Workflow defs can be JSON, but *runtime dependencies* are modeled as graph edges between `stage_run` records.

## Execution as immutable bundles

Instead of streaming logs into the DB, we write execution bundles to disk and store pointers in the DB.

## Leases vs. exactly-once

At-least-once + idempotent completion is simpler and robust for v0.

## Shell blocked by default

Running `bash -c "..."` is too opaque to validate reliably.
Explicit opt-in required (`allow_shell`).

## JJ colocated workspaces (daemon-managed)

The daemon performs minimal VCS automation:

- initialize `jj` in colocated mode when needed
- create a per-run working copy via `jj workspace add`

This keeps agents focused on execution while giving predictable isolation.

## Run pinning (v0 safety)

Because stages may depend on filesystem mutations, the daemon pins a run to a single agent via an expiring `run.owner_agent` lease. This is a pragmatic v0 choice; later phases can relax this by committing at stage boundaries and passing revision ids downstream.

## Slurm as an executor backend

We treat Slurm as just another execution backend for `exec_block` stages. It keeps the core model stable while allowing cluster offload when a shared filesystem is available.
