# Specs

## Data model

### WorkflowDef

Logical workflow (name + metadata).

Fields:
- `name: string` (unique)
- `description: string?`
- `created_at_ms: number`

### WorkflowVersion

Immutable version of a workflow definition.

Fields:
- `workflow_name: string`
- `hash: string` (sha256 of canonical JSON)
- `spec: WorkflowSpec` (stored as JSON)
- `created_at_ms: number`

### Run

Fields:
- `id: ULID`
- `project_path: string`
- `intent: IntentSpec`
- `workflow_name: string`
- `workflow_hash: string`
- `status: run_status`
- timestamps

### StageRun

Fields:
- `id: ULID`
- `run_id: ULID`
- `node_id: string` (from workflow)
- `kind: stage_kind`
- `deps: ULID[]` (stage IDs that must succeed)
- `status: stage_status`
- `exec: ExecBlockSpec?` (snapshot for exec stages)
- `output_revision: string?`
- timestamps

### Job

Fields:
- `id: ULID`
- `stage_id: ULID`
- `status: job_status`
- lease fields:
  - `lease_owner: string?`
  - `lease_token: string?`
  - `lease_expires_at_ms: number?`
- timestamps

### ExecAttempt

Fields:
- `id: ULID`
- `job_id: ULID`
- `stage_id: ULID`
- `status: succeeded|failed`
- `artifact_dir: string`
- `commands: CommandResult[]`
- timestamps

## WorkflowSpec schema

```json
{
  "name": "rust-ci",
  "description": "Build & test",
  "nodes": [
    {
      "id": "build",
      "type": "exec_block",
      "exec": {
        "executor": "local",
        "workdir": ".",
        "env": {},
        "commands": [{"argv": ["cargo", "build", "--locked"]}]
      }
    }
  ],
  "edges": [{"from": "build", "to": "test"}]
}
```

## API

### POST /v1/runs/enqueue

Body: `RunEnqueueRequest`

Returns: `{ run_id, workflow_hash }`

### POST /v1/agent/claim

Body: `{ agent_id }`

Returns either:
- `204 No Content` if no job available
- `200 OK` with `JobClaim`

JobClaim includes:
- job + lease token/expiry
- stage kind + exec block snapshot
- project path + workspace hints

### POST /v1/agent/complete

Body: `JobCompleteRequest`

Must include correct `lease_token`.
Updates job/stage/run statuses.

## Status transitions

StageRun:
- `pending` → `queued` (scheduler creates job)
- `queued` → `running` (agent claims job)
- `running` → `succeeded|failed` (agent complete)
- `pending` → `needs_human` (gate stage w/ approval)
- `needs_human` → `pending` (future: approval endpoint)

Job:
- `queued` → `running` (lease token issued)
- `running` → `succeeded|failed`
- `running` (lease expired) → eligible to be reclaimed

## Artifacts layout (agent)

`{state_dir}/artifacts/{run_id}/{stage_id}/{job_id}/`

Contains:
- `manifest.json`
- `{cmd_index}-{cmd_name}/stdout.log`
- `{cmd_index}-{cmd_name}/stderr.log`
- `{cmd_index}-{cmd_name}/meta.json`
