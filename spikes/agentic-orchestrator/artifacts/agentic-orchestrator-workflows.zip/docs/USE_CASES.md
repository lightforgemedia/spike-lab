# Use cases and scenario coverage

The following scenarios guided the MVP:

1. **Single-stage lint**: One exec_block runs `cargo fmt --check`.
2. **Build then test**: Two stages with dependency edge.
3. **Fan-out tests**: Build → (unit, integration, clippy) in parallel.
4. **Fan-in**: Multiple prerequisite stages gate a final packaging stage.
5. **Gate stage**: Require approval before running deployment stage (stage enters `needs_human`).
6. **Emit stage**: Emit a JSON summary artifact after test completion.
7. **At-least-once**: Agent crashes mid-job; lease expires and another agent reclaims.
8. **Idempotent complete**: Agent retries HTTP POST /complete; daemon ignores duplicates.
9. **Non-zero exit code**: Command fails; stage + run marked failed; downstream not scheduled.
10. **Command timeout**: Agent kills process and marks failed.
11. **Unsafe command**: Exec contains `sudo rm -rf /`; rejected in validation.
12. **Path escape attempt**: Workdir `../../..`; rejected by agent containment check.
13. **Missing node in edge**: DAG validation rejects unknown node references.
14. **Cycle in DAG**: Validation rejects cycles.
15. **Workflow version reuse**: Same workflow spec yields same hash and reuses workflow_version.
16. **Different workflow versions**: Any change in spec creates a new workflow_version.
17. **Multiple agents**: Two agents claim from one project; load spreads by job queue.
18. **DB restart**: Daemon restarts; scheduler resumes pending stages/jobs from DB.
19. **Workspace mode**: If `jj` installed, agent creates a workspace directory per stage.
20. **Local-only mode**: No `jj`; agent executes directly under project path.

Gaps (intentional for v0):
- no secret management
- no remote artifact transport
- no complex retries/backoff
