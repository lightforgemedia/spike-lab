use anyhow::Context;
use std::path::{Path, PathBuf};
use std::process::Stdio;

/// A minimal "VCS adapter":
/// - If `jj` exists: create a workspace directory using `jj workspace add`.
/// - Otherwise: use the project directory directly.
///
/// For v0 we do not attempt to enforce revision correctness beyond best-effort.
/// The agent reports output revision if `jj log -r @` works.
#[derive(Clone, Debug)]
pub struct Workspace {
    pub root: PathBuf,
    pub uses_jj: bool,
}

pub async fn prepare_workspace(
    project_path: &Path,
    state_dir: &Path,
    run_id: &str,
    stage_id: &str,
    job_id: &str,
    input_revisions: &[String],
) -> anyhow::Result<Workspace> {
    let workspaces_root = state_dir.join("workspaces").join(run_id).join(stage_id).join(job_id);
    tokio::fs::create_dir_all(&workspaces_root).await?;

    if jj_available().await {
        // `jj workspace add <dest>` must be run from within the repository root.
        // We create a new workspace directory for the job.
        let status = tokio::process::Command::new("jj")
            .arg("workspace")
            .arg("add")
            .arg(&workspaces_root)
            .current_dir(project_path)
            .stdout(Stdio::null())
            .stderr(Stdio::piped())
            .status()
            .await
            .context("run jj workspace add")?;

        if status.success() {
            // Best-effort: move working copy to the first input revision, if provided.
            if let Some(first) = input_revisions.first() {
                let _ = tokio::process::Command::new("jj")
                    .arg("new")
                    .arg(first)
                    .current_dir(&workspaces_root)
                    .stdout(Stdio::null())
                    .stderr(Stdio::null())
                    .status()
                    .await;
            }
            return Ok(Workspace { root: workspaces_root, uses_jj: true });
        }
    }

    // Fallback: run directly in project dir
    Ok(Workspace { root: project_path.to_path_buf(), uses_jj: false })
}

async fn jj_available() -> bool {
    tokio::process::Command::new("jj")
        .arg("--version")
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .await
        .map(|s| s.success())
        .unwrap_or(false)
}

/// Try to capture a useful revision identifier from jj.
pub async fn current_revision(workspace_root: &Path) -> Option<String> {
    let out = tokio::process::Command::new("jj")
        .arg("log")
        .arg("-r")
        .arg("@")
        .arg("--no-graph")
        .arg("-T")
        .arg("change_id.short() ++ "\n"")
        .current_dir(workspace_root)
        .output()
        .await
        .ok()?;

    if !out.status.success() {
        return None;
    }
    let s = String::from_utf8_lossy(&out.stdout).trim().to_string();
    if s.is_empty() { None } else { Some(s) }
}
