# Agentic Orchestrator (SurrealDB + staged exec_blocks)

This project is a **local-first** agentic CI/task orchestrator:

- Workflows are stored (versioned) in SurrealDB.
- A run enqueues a workflow DAG, materializes stage-runs, and schedules them.
- Agents claim jobs with a lease, execute `exec_block`s, and report results.
- Each command writes stdout/stderr to a unique on-disk artifact directory; results are summarized in DB.

> Status: MVP skeleton. The code is intentionally minimal and biased toward clarity. It is designed to be extended.

## What’s new in this zip (vs prior drafts)

- **`workflow_def` and `workflow_version` tables**:
  - workflow definitions are stored and versioned by a stable content hash.
- **`POST /v1/runs/enqueue` now accepts a full DAG definition** in the request body (not a hardcoded demo).
- A **simple scheduler loop** materializes `stage_run` → `job` for `exec_block` nodes once dependencies succeed.

## Requirements

- Rust toolchain: `rustc 1.80.1+` (pinned via `rust-toolchain.toml`).
- SurrealDB is used **embedded** via SurrealKV (`surrealkv://...`).
- Optional:
  - `jj` (Jujutsu) for multi-workspace execution (agent will fall back if absent).
  - `git` for repo operations (fallback).

## Quickstart

### 1) Run the daemon

```bash
cargo run -p orchestrator-daemon -- \
  --listen 127.0.0.1:7777 \
  --db-url surrealkv://.orchestrator/db \
  --ns orchestrator --db orchestrator
```

### 2) Enqueue a run from an example JSON

```bash
cargo run -p orchestratorctl -- \
  enqueue --daemon http://127.0.0.1:7777 \
  --file docs/examples/enqueue_run.json
```

### 3) Run an agent

```bash
cargo run -p orchestrator-agent -- \
  --daemon http://127.0.0.1:7777 \
  --agent-id agent-01 \
  --state-dir .orchestrator/agent-01
```

### 4) Watch run status

```bash
cargo run -p orchestratorctl -- \
  run get --daemon http://127.0.0.1:7777 --run-id <RUN_ID>
```

## API overview

- `POST /v1/runs/enqueue` — enqueue a new run with workflow DAG
- `GET  /v1/runs/{run_id}` — run summary
- `GET  /v1/runs/{run_id}/stages` — stage list
- `POST /v1/agent/claim` — agent claims next job
- `POST /v1/agent/complete` — agent reports completion

See `docs/SPECS.md` for full schemas.

## Safety / validation (MVP)

- Static validation rejects:
  - empty command argv
  - `sudo` and a small denylist of obviously destructive commands
  - `sh -c` / `bash -c` unless `allow_shell: true`
- Agent performs an additional workdir containment check (no escaping `workspace_root`).

This is not a complete sandbox. Treat it as a guardrail, not a security boundary.

## Repo layout

- `crates/orchestrator-core` — types, hashing, validation helpers
- `crates/orchestrator-daemon` — API + scheduler + SurrealDB persistence
- `crates/orchestrator-agent` — job loop + executor + artifacts
- `crates/orchestratorctl` — tiny CLI client (enqueue, get runs, list workflows)

## Docs

- `docs/DECISIONS.md`
- `docs/PRINCIPLES.md`
- `docs/SPECS.md`
- `docs/USE_CASES.md`
- `docs/REJECTED.md`
- `docs/SCHEMA.surql`
