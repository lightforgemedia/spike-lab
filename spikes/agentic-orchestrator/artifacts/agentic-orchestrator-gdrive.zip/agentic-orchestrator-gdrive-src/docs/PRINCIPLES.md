# Principles applied

- **FCIS**: Prefer "first correct implementation" over premature generalization (scheduler and DB model are simple).
- **DRY**: Shared types/validation live in `orchestrator-core`.
- **KISS**: Workflow execution is reduced to: DAG → stage-runs → jobs → artifacts.
- **SRP**: Daemon schedules and persists; agent executes commands; CLI submits/inspects.
- **Explicit over implicit**: IDs, statuses, timestamps, and artifact paths are explicit fields.
- **Fail closed**: Validation rejects dangerous patterns by default (e.g., `sudo`, shell execution without opt-in).
