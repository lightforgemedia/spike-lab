use clap::Parser;
use orchestrator_core::{now_ms, AgentClaimRequest, CommandResult, ExecAttemptRow, JobClaim, JobCompleteRequest, JobStatus};
use std::path::{Path, PathBuf};
use tracing::{info, warn};

mod executor;
mod vcs;

#[derive(Parser, Debug)]
#[command(name = "orchestrator-agent")]
struct Args {
    #[arg(long)]
    daemon: String,
    #[arg(long)]
    agent_id: String,
    #[arg(long, default_value = ".orchestrator/agent")]
    state_dir: PathBuf,
    #[arg(long, default_value_t = 1500)]
    poll_ms: u64,
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(tracing_subscriber::EnvFilter::from_default_env())
        .init();

    let args = Args::parse();
    tokio::fs::create_dir_all(&args.state_dir).await?;

    let client = reqwest::Client::new();
    let poll = std::time::Duration::from_millis(args.poll_ms);

    loop {
        let claim = claim_job(&client, &args.daemon, &args.agent_id).await?;
        if let Some(job) = claim {
            info!(job_id=%job.job_id, stage_id=%job.stage_id, "claimed job");
            let attempt = executor::run_job(&args, &job).await;

            let (succeeded, attempt_row, output_rev) = match attempt {
                Ok((attempt_row, output_rev)) => (true, attempt_row, output_rev),
                Err((attempt_row, output_rev)) => (false, attempt_row, output_rev),
            };

            let complete = JobCompleteRequest {
                agent_id: args.agent_id.clone(),
                job_id: job.job_id.clone(),
                lease_token: job.lease_token.clone(),
                succeeded,
                output_revision: output_rev,
                attempt: attempt_row,
            };

            if let Err(e) = complete_job(&client, &args.daemon, &complete).await {
                warn!(error=?e, "failed to report completion (you can retry safely)");
            }
        } else {
            tokio::time::sleep(poll).await;
        }
    }
}

async fn claim_job(client: &reqwest::Client, daemon: &str, agent_id: &str) -> anyhow::Result<Option<JobClaim>> {
    let url = format!("{}/v1/agent/claim", daemon.trim_end_matches('/'));
    let resp = client.post(url).json(&AgentClaimRequest { agent_id: agent_id.to_string() }).send().await?;
    if resp.status() == reqwest::StatusCode::NO_CONTENT {
        return Ok(None);
    }
    let job: JobClaim = resp.error_for_status()?.json().await?;
    Ok(Some(job))
}

async fn complete_job(client: &reqwest::Client, daemon: &str, req: &JobCompleteRequest) -> anyhow::Result<()> {
    let url = format!("{}/v1/agent/complete", daemon.trim_end_matches('/'));
    client.post(url).json(req).send().await?.error_for_status()?;
    Ok(())
}
