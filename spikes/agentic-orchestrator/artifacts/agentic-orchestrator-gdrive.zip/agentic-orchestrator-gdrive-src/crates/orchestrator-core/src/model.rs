use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::BTreeMap;

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct IntentSpec {
    pub goal: String,
    #[serde(default)]
    pub notes: Option<String>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct RunEnqueueRequest {
    pub project_path: String,
    pub intent: IntentSpec,
    pub workflow: WorkflowSpec,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct RunEnqueueResponse {
    pub run_id: String,
    pub workflow_hash: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct WorkflowSpec {
    pub name: String,
    #[serde(default)]
    pub description: Option<String>,
    pub nodes: Vec<WorkflowNodeSpec>,
    #[serde(default)]
    pub edges: Vec<WorkflowEdgeSpec>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct WorkflowNodeSpec {
    pub id: String,
    #[serde(rename = "type")]
    pub kind: StageKind,
    #[serde(default)]
    pub name: Option<String>,

    /// Used when kind == exec_block.
    #[serde(default)]
    pub exec: Option<ExecBlockSpec>,

    /// Free-form config for future stage types.
    #[serde(default)]
    pub config: Option<Value>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct WorkflowEdgeSpec {
    pub from: String,
    pub to: String,
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum StageKind {
    ExecBlock,
    Gate,
    Emit,
    Noop,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ExecBlockSpec {
    pub executor: ExecutorKind,
    #[serde(default)]
    pub workdir: Option<String>,
    #[serde(default)]
    pub env: BTreeMap<String, String>,
    pub commands: Vec<CommandSpec>,
    #[serde(default)]
    pub timeout_secs: Option<u64>,
    #[serde(default)]
    pub allow_shell: bool,

    /// Maximum attempts for this stage.
    /// If omitted, defaults to 1.
    #[serde(default)]
    pub max_attempts: Option<u32>,
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ExecutorKind {
    Local,
    Slurm,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct CommandSpec {
    pub argv: Vec<String>,
    #[serde(default)]
    pub name: Option<String>,
    #[serde(default)]
    pub env: BTreeMap<String, String>,
    #[serde(default)]
    pub timeout_secs: Option<u64>,
    #[serde(default)]
    pub allow_failure: bool,
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum RunStatus {
    Pending,
    Running,
    Succeeded,
    Failed,
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum StageStatus {
    Pending,
    Queued,
    Running,
    Succeeded,
    Failed,
    NeedsHuman,
    Skipped,
}

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum JobStatus {
    Queued,
    Running,
    Succeeded,
    Failed,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct RunRow {
    pub id: String,
    pub project_path: String,
    pub intent: IntentSpec,
    pub workflow_name: String,
    pub workflow_hash: String,
    pub status: RunStatus,
    pub created_at_ms: i64,
    pub updated_at_ms: i64,
}

fn default_max_attempts() -> u32 {
    1
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct StageRunRow {
    pub id: String,
    pub run_id: String,
    pub node_id: String,
    pub kind: StageKind,
    pub deps: Vec<String>,
    pub status: StageStatus,
    #[serde(default)]
    pub exec: Option<ExecBlockSpec>,
    #[serde(default)]
    pub config: Option<Value>,
    #[serde(default)]
    pub output_revision: Option<String>,

    /// How many failed attempts have occurred for this stage.
    #[serde(default)]
    pub attempts_used: u32,

    /// Maximum number of attempts allowed for this stage.
    #[serde(default = "default_max_attempts")]
    pub max_attempts: u32,

    pub created_at_ms: i64,
    pub updated_at_ms: i64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct JobRow {
    pub id: String,
    pub stage_id: String,
    pub status: JobStatus,
    #[serde(default)]
    pub lease_owner: Option<String>,
    #[serde(default)]
    pub lease_token: Option<String>,
    #[serde(default)]
    pub lease_expires_at_ms: Option<i64>,
    pub attempt: u32,
    pub created_at_ms: i64,
    pub updated_at_ms: i64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct WorkflowDefRow {
    pub name: String,
    #[serde(default)]
    pub description: Option<String>,
    pub created_at_ms: i64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct WorkflowVersionRow {
    pub workflow_name: String,
    pub hash: String,
    pub spec: WorkflowSpec,
    pub created_at_ms: i64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ExecAttemptRow {
    pub id: String,
    pub job_id: String,
    pub stage_id: String,
    pub status: JobStatus,
    pub artifact_dir: String,

    /// Optional bundle URI stored by the daemon after upload.
    #[serde(default)]
    pub artifact_bundle: Option<String>,

    pub started_at_ms: i64,
    pub finished_at_ms: i64,
    pub commands: Vec<CommandResult>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct CommandResult {
    pub index: usize,
    pub name: String,
    pub argv: Vec<String>,
    pub exit_code: i32,
    pub started_at_ms: i64,
    pub finished_at_ms: i64,
    pub stdout_path: String,
    pub stderr_path: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct AgentClaimRequest {
    pub agent_id: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct JobClaim {
    pub job_id: String,
    pub stage_id: String,
    pub run_id: String,
    pub lease_token: String,
    pub lease_expires_at_ms: i64,
    pub project_path: String,
    pub kind: StageKind,
    pub exec: Option<ExecBlockSpec>,
    /// Best-effort input revision(s) from upstream stages.
    #[serde(default)]
    pub input_revisions: Vec<String>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct JobCompleteRequest {
    pub agent_id: String,
    pub job_id: String,
    pub lease_token: String,
    pub succeeded: bool,
    #[serde(default)]
    pub output_revision: Option<String>,
    pub attempt: ExecAttemptRow,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ArtifactUploadResponse {
    pub artifact_uri: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct StageApprovalRequest {
    pub approver: String,
    #[serde(default)]
    pub note: Option<String>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct StageApprovalResponse {
    pub stage_id: String,
    pub status: StageStatus,
}
