use anyhow::Context;
use axum::{
    body::Bytes,
    extract::{DefaultBodyLimit, Path as AxumPath, State},
    response::IntoResponse,
    routing::{get, post},
    Json, Router,
};
use orchestrator_core::{
    now_ms, validate_workflow, workflow_hash, AgentClaimRequest, JobCompleteRequest,
    RunEnqueueRequest, RunEnqueueResponse, StageApprovalRequest, StageApprovalResponse,
    ArtifactUploadResponse, RunRow, StageRunRow, WorkflowDefRow, WorkflowVersionRow,
};
use surrealdb::engine::any::connect;
use surrealdb::Surreal;
use tokio::sync::oneshot;
use tower_http::trace::TraceLayer;
use tracing::info;
use ulid::Ulid;

use std::{net::SocketAddr, sync::Arc};

mod schema;
mod scheduler;
mod gdrive;
mod state;

use state::AppState;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let cfg = state::Config::from_args();

    tracing_subscriber::fmt()
        .with_env_filter(tracing_subscriber::EnvFilter::from_default_env())
        .init();

    // Connect DB (embedded by default)
    let db: Surreal<surrealdb::engine::any::Any> = connect(&cfg.db_url)
        .await
        .with_context(|| format!("connect surrealdb at {}", cfg.db_url))?;

    db.use_ns(&cfg.ns).use_db(&cfg.db).await.context("use ns/db")?;

    // Apply schema on startup
    db.query(schema::SCHEMA).await.context("apply schema")?;

    let state = Arc::new(AppState { cfg, db });

    // Scheduler loop
    let (stop_tx, stop_rx) = oneshot::channel::<()>();
    tokio::spawn(scheduler::scheduler_loop(state.clone(), stop_rx));

    let app = Router::new()
        .route("/healthz", get(|| async { "ok" }))
        .route("/v1/runs/enqueue", post(api_enqueue_run))
        .route("/v1/runs/:run_id", get(api_get_run))
        .route("/v1/runs/:run_id/stages", get(api_list_stages))
        .route("/v1/workflows", get(api_list_workflows))
        .route("/v1/workflows/:name/versions", get(api_list_workflow_versions))
        .route("/v1/stages/:stage_id/approve", post(api_stage_approve))
        .route("/v1/stages/:stage_id/reject", post(api_stage_reject))
        .route("/v1/jobs/:job_id/artifacts", post(api_job_upload_artifacts))
        .route("/v1/agent/claim", post(api_agent_claim))
        .route("/v1/agent/complete", post(api_agent_complete))
        .layer(TraceLayer::new_for_http())
        .layer(DefaultBodyLimit::max(state.cfg.max_upload_bytes))
        .with_state(state.clone());

    let addr: SocketAddr = state.cfg.listen.parse().context("parse listen addr")?;
    info!(%addr, "daemon listening");

    // Clean shutdown on ctrl-c
    let server = axum::serve(tokio::net::TcpListener::bind(addr).await?, app);
    tokio::select! {
        res = server => {
            res.context("server error")?;
        }
        _ = tokio::signal::ctrl_c() => {
            let _ = stop_tx.send(());
            info!("shutdown requested");
        }
    }

    Ok(())
}

async fn api_enqueue_run(
    State(state): State<Arc<AppState>>,
    Json(req): Json<RunEnqueueRequest>,
) -> Result<Json<RunEnqueueResponse>, state::ApiError> {
    validate_workflow(&req.workflow).map_err(state::ApiError::bad_request)?;
    let hash = workflow_hash(&req.workflow).map_err(state::ApiError::internal)?;

    // Upsert workflow_def by name
    let wf_name = req.workflow.name.clone();
    let now = now_ms();

    let existing: Vec<WorkflowDefRow> = state
        .db
        .query("SELECT * FROM workflow_def WHERE name = $name LIMIT 1;")
        .bind(("name", wf_name.clone()))
        .await
        .map_err(state::ApiError::internal)?
        .take(0)
        .map_err(state::ApiError::internal)?;

    if existing.is_empty() {
        let _created: Vec<WorkflowDefRow> = state
            .db
            .query("CREATE workflow_def SET name=$name, description=$desc, created_at_ms=$now;")
            .bind(("name", wf_name.clone()))
            .bind(("desc", req.workflow.description.clone()))
            .bind(("now", now))
            .await
            .map_err(state::ApiError::internal)?
            .take(0)
            .map_err(state::ApiError::internal)?;
    }

    // Upsert workflow_version by (name, hash)
    let existing_v: Vec<WorkflowVersionRow> = state
        .db
        .query("SELECT * FROM workflow_version WHERE workflow_name=$name AND hash=$hash LIMIT 1;")
        .bind(("name", wf_name.clone()))
        .bind(("hash", hash.clone()))
        .await
        .map_err(state::ApiError::internal)?
        .take(0)
        .map_err(state::ApiError::internal)?;

    if existing_v.is_empty() {
        let _created: Vec<WorkflowVersionRow> = state
            .db
            .query(
                "CREATE workflow_version SET workflow_name=$name, hash=$hash, spec=$spec, created_at_ms=$now;",
            )
            .bind(("name", wf_name.clone()))
            .bind(("hash", hash.clone()))
            .bind(("spec", req.workflow.clone()))
            .bind(("now", now))
            .await
            .map_err(state::ApiError::internal)?
            .take(0)
            .map_err(state::ApiError::internal)?;
    }

    // Create run
    let run_id = Ulid::new().to_string();
    let run = RunRow {
        id: run_id.clone(),
        project_path: req.project_path.clone(),
        intent: req.intent.clone(),
        workflow_name: wf_name.clone(),
        workflow_hash: hash.clone(),
        status: orchestrator_core::RunStatus::Pending,
        created_at_ms: now,
        updated_at_ms: now,
    };

    let _created: Option<RunRow> = state
        .db
        .create(("run", run_id.as_str()))
        .content(run)
        .await
        .map_err(state::ApiError::internal)?;

    // Materialize stages
    let mut node_to_stage: std::collections::HashMap<String, String> = std::collections::HashMap::new();
    for node in &req.workflow.nodes {
        node_to_stage.insert(node.id.clone(), Ulid::new().to_string());
    }

    for node in &req.workflow.nodes {
        let stage_id = node_to_stage.get(&node.id).expect("stage id exists").clone();

        let deps: Vec<String> = req
            .workflow
            .edges
            .iter()
            .filter(|e| e.to == node.id)
            .filter_map(|e| node_to_stage.get(&e.from).cloned())
            .collect();

        let max_attempts = node
            .exec
            .as_ref()
            .and_then(|e| e.max_attempts)
            .unwrap_or(1);

        let stage = StageRunRow {
            id: stage_id.clone(),
            run_id: run_id.clone(),
            node_id: node.id.clone(),
            kind: node.kind,
            deps,
            status: orchestrator_core::StageStatus::Pending,
            exec: node.exec.clone(),
            config: node.config.clone(),
            output_revision: None,
            attempts_used: 0,
            max_attempts,
            created_at_ms: now,
            updated_at_ms: now,
        };

        let _created: Option<StageRunRow> = state
            .db
            .create(("stage_run", stage_id.as_str()))
            .content(stage)
            .await
            .map_err(state::ApiError::internal)?;
    }

    Ok(Json(RunEnqueueResponse {
        run_id,
        workflow_hash: hash,
    }))
}

async fn api_get_run(
    State(state): State<Arc<AppState>>,
    AxumPath(run_id): AxumPath<String>,
) -> Result<Json<RunRow>, state::ApiError> {
    let run: Option<RunRow> = state
        .db
        .select(("run", run_id.as_str()))
        .await
        .map_err(state::ApiError::internal)?;
    run.map(Json)
        .ok_or_else(|| state::ApiError::not_found("run not found"))
}

async fn api_list_stages(
    State(state): State<Arc<AppState>>,
    AxumPath(run_id): AxumPath<String>,
) -> Result<Json<Vec<StageRunRow>>, state::ApiError> {
    let stages: Vec<StageRunRow> = state
        .db
        .query("SELECT * FROM stage_run WHERE run_id = $run_id ORDER BY created_at_ms;")
        .bind(("run_id", run_id))
        .await
        .map_err(state::ApiError::internal)?
        .take(0)
        .map_err(state::ApiError::internal)?;
    Ok(Json(stages))
}

async fn api_list_workflows(
    State(state): State<Arc<AppState>>,
) -> Result<Json<Vec<WorkflowDefRow>>, state::ApiError> {
    let rows: Vec<WorkflowDefRow> = state
        .db
        .query("SELECT * FROM workflow_def ORDER BY name;")
        .await
        .map_err(state::ApiError::internal)?
        .take(0)
        .map_err(state::ApiError::internal)?;
    Ok(Json(rows))
}

async fn api_list_workflow_versions(
    State(state): State<Arc<AppState>>,
    AxumPath(name): AxumPath<String>,
) -> Result<Json<Vec<WorkflowVersionRow>>, state::ApiError> {
    let rows: Vec<WorkflowVersionRow> = state
        .db
        .query("SELECT * FROM workflow_version WHERE workflow_name=$name ORDER BY created_at_ms DESC;")
        .bind(("name", name))
        .await
        .map_err(state::ApiError::internal)?
        .take(0)
        .map_err(state::ApiError::internal)?;
    Ok(Json(rows))
}

async fn api_stage_approve(
    State(state): State<Arc<AppState>>,
    AxumPath(stage_id): AxumPath<String>,
    Json(req): Json<StageApprovalRequest>,
) -> Result<Json<StageApprovalResponse>, state::ApiError> {
    let resp = state::approve_stage(&state, &stage_id, req).await?;
    Ok(Json(resp))
}

async fn api_stage_reject(
    State(state): State<Arc<AppState>>,
    AxumPath(stage_id): AxumPath<String>,
    Json(req): Json<StageApprovalRequest>,
) -> Result<Json<StageApprovalResponse>, state::ApiError> {
    let resp = state::reject_stage(&state, &stage_id, req).await?;
    Ok(Json(resp))
}

async fn api_job_upload_artifacts(
    State(state): State<Arc<AppState>>,
    AxumPath(job_id): AxumPath<String>,
    bytes: Bytes,
) -> Result<Json<ArtifactUploadResponse>, state::ApiError> {
    let resp = state::store_artifact_bundle(&state, &job_id, bytes).await?;
    Ok(Json(resp))
}

async fn api_agent_claim(
    State(state): State<Arc<AppState>>,
    Json(req): Json<AgentClaimRequest>,
) -> Result<axum::response::Response, state::ApiError> {
    let claim = state::claim_next_job(&state, &req.agent_id).await?;
    match claim {
        None => Ok(axum::http::StatusCode::NO_CONTENT.into_response()),
        Some(c) => Ok(Json(c).into_response()),
    }
}

async fn api_agent_complete(
    State(state): State<Arc<AppState>>,
    Json(req): Json<JobCompleteRequest>,
) -> Result<axum::http::StatusCode, state::ApiError> {
    state::complete_job(&state, req).await?;
    Ok(axum::http::StatusCode::OK)
}
