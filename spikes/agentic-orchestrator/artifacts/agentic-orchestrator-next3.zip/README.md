# Agentic Orchestrator (embedded SurrealDB + jj workspaces)

A minimal-but-structured agentic CI orchestration prototype:

- **Embedded SurrealDB (SurrealKV)** for state + a graph-style stage dependency model.
- **Multiple agents** pulling jobs from a daemon over HTTP.
- **Revision-aware handoff** via **Jujutsu (jj) workspaces**: each stage runs in a workspace created from the upstream stage's output revision.
- **Exec blocks**: each job can run multiple commands; stdout/stderr go to unique per-run disk locations with timestamps + status.
- **Heartbeats + leases**: jobs are claimed with a lease token and renewed periodically to avoid duplicate execution.
- **Optional Slurm executor** (submit + poll + sacct hardening).
- **Optional retention / GC** (disabled by default, to “keep everything for now”).

This is intentionally small and explicit. It is not a sandbox and should be treated as an internal tool.

## Repository layout

- `crates/orchestrator-daemon` – HTTP API + scheduler + embedded SurrealDB
- `crates/orchestrator-agent` – agent that claims jobs and executes them
- `crates/orchestrator-core` – shared models + command safety guardrails
- `docs/` – specs, decisions, scenarios, rejected approaches

## Quick start (single machine)

Prereqs:
- Rust stable toolchain
- Optional but recommended: `jj` installed in the project repo you run the daemon in
- Optional: Slurm (`sbatch`, `squeue`, `sacct`) if you want Slurm executor jobs

In a git repo you want to run jobs against:

```bash
# from the repo root
cargo build --release

# terminal 1: start daemon
./target/release/orchestrator-daemon --listen 127.0.0.1:8080

# terminal 2: start one or more agents
./target/release/orchestrator-agent --daemon-url http://127.0.0.1:8080 --cap linux
```

Enqueue a demo run:

```bash
curl -X POST http://127.0.0.1:8080/v1/demo/enqueue
```

Run bundles (logs/artifacts) and workspaces land in:

- `.orchestrator/runs/<run_id>/...`
- `.orchestrator/workspaces/<run_id>/...`

## Notes on safety

The validator blocks a small set of “obviously dangerous” commands and does best-effort checking of
destructive file operations (e.g., `rm`, `mv`) to ensure target paths stay under the workspace.

**Shell invocations are blocked by default** (`bash`, `sh`, …) because they can hide arbitrary commands.
You can opt in per command via `allow_shell: true`.

See `docs/security.md`.

## Status

This is a prototype that demonstrates the execution flow and data model. The next highest-value additions
are listed in `docs/roadmap.md`.
