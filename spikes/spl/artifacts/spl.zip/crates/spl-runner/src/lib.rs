pub mod config;
pub mod doctor;
pub mod runner;
pub mod util;

pub use config::*;
pub use doctor::*;
pub use runner::*;
pub use util::*;


#[cfg(test)]
mod fixture_tests {
    use super::*;
    use std::path::Path;

    #[test]
    fn loads_and_compiles_sc01_spec_pack() {
        let path = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../../fixtures/scenarios/SC-01-happy-path/spec_pack.yaml");
        let pack = spl_spec::load_spec_pack(&path).unwrap();
        let draft = spl_spec::compile_revision_draft(&pack);
        assert_eq!(draft.profile, "standard");
        assert!(!draft.spec_hash.is_empty());
    }
}
