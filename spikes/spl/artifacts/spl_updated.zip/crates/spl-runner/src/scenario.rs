use std::path::{Path, PathBuf};

use anyhow::{anyhow, Context, Result};
use serde::Deserialize;
use spl_core::{GateName, GateStatus, TaskStatus, VcsType};

#[derive(Debug, Deserialize)]
pub struct ScenarioExpected {
    pub scenario_id: String,
    pub vcs_modes: Vec<String>,
    pub task: ScenarioExpectedTask,
    pub messages: ScenarioExpectedMessages,
}

#[derive(Debug, Deserialize)]
pub struct ScenarioExpectedTask {
    pub expect_final_status: String,
}

#[derive(Debug, Deserialize)]
pub struct ScenarioExpectedMessages {
    pub ask_required: bool,
}

#[derive(Debug)]
pub struct ScenarioResult {
    pub final_status: TaskStatus,
    pub ask_emitted: bool,
    pub executed_gates: Vec<(GateName, GateStatus)>,
}

pub fn load_expected(dir: &Path) -> Result<ScenarioExpected> {
    let p = dir.join("expected.yaml");
    let s = std::fs::read_to_string(&p).with_context(|| format!("read expected.yaml: {}", p.display()))?;
    let exp: ScenarioExpected = serde_yaml::from_str(&s).with_context(|| "parse expected.yaml")?;
    Ok(exp)
}

/// Minimal fixture-mode scenario simulation:
/// - loads spec pack required gate list (string names)
/// - reads gate fixture files under gates/
/// - stops on first FAIL
/// - if all execute gates pass, runs post_smoke (land) if required
///
/// This does NOT run VCS operations. VCS parity is enforced by adapter contract tests.
/// These scenario tests are about SPL semantics and fixture ingestion.
pub fn simulate(dir: &Path, _vcs: VcsType) -> Result<ScenarioResult> {
    let spec_path = dir.join("spec_pack.yaml");
    let pack = spl_spec::load_spec_pack(&spec_path)?;
    let draft = spl_spec::compile_revision_draft(&pack);

    // Gate list comes from spec pack required list when present; else profile default.
    let required = pack
        .gates
        .as_ref()
        .map(|g| g.required.clone())
        .unwrap_or_else(|| draft.required_gates.iter().map(|g| format!("{:?}", g)).collect());

    // Split into execute gates and post_smoke (land)
    let mut execute_gates: Vec<GateName> = Vec::new();
    let mut include_post_smoke = false;
    for name in required {
        let g = parse_gate_name(&name)?;
        if g == GateName::PostSmoke {
            include_post_smoke = true;
        } else {
            execute_gates.push(g);
        }
    }

    let mut executed = Vec::new();

    // Execute lane simulation
    for g in execute_gates {
        let st = read_gate_status(dir, &g)?;
        executed.push((g.clone(), st.clone()));
        if st == GateStatus::Fail {
            return Ok(ScenarioResult {
                final_status: TaskStatus::BlockedFailure,
                ask_emitted: false,
                executed_gates: executed,
            });
        }
    }

    // Land lane simulation (post_smoke)
    if include_post_smoke {
        let g = GateName::PostSmoke;
        let st = read_gate_status(dir, &g)?;
        executed.push((g.clone(), st.clone()));
        if st == GateStatus::Fail {
            return Ok(ScenarioResult {
                final_status: TaskStatus::BlockedFailure,
                ask_emitted: false,
                executed_gates: executed,
            });
        }
    }

    Ok(ScenarioResult {
        final_status: TaskStatus::Done,
        ask_emitted: false,
        executed_gates: executed,
    })
}

fn parse_gate_name(s: &str) -> Result<GateName> {
    let n = s.trim();
    match n {
        "spec_compile" => Ok(GateName::SpecCompile),
        "ctx_pack" => Ok(GateName::CtxPack),
        "pre_smoke" => Ok(GateName::PreSmoke),
        "delegate" => Ok(GateName::Delegate),
        "audit" => Ok(GateName::Audit),
        "adversarial_review" => Ok(GateName::AdversarialReview),
        "validate" => Ok(GateName::Validate),
        "post_smoke" => Ok(GateName::PostSmoke),
        "land" => Ok(GateName::Land),
        _ => Err(anyhow!("unknown gate name in spec_pack: {n}")),
    }
}

fn read_gate_status(dir: &Path, gate: &GateName) -> Result<GateStatus> {
    let gates_dir = dir.join("gates");
    match gate {
        GateName::PreSmoke => parse_txt_status(&gates_dir.join("pre_smoke.txt")),
        GateName::PostSmoke => parse_txt_status(&gates_dir.join("post_smoke.txt")),
        GateName::Audit => parse_json_result(&gates_dir.join("audit.json")),
        GateName::AdversarialReview => parse_json_result(&gates_dir.join("review.json")),
        GateName::Validate => parse_json_result(&gates_dir.join("validate.json")),
        // For now, fixture scenarios don't simulate these; treat as PASS if not present.
        GateName::SpecCompile | GateName::CtxPack | GateName::Delegate | GateName::Land => Ok(GateStatus::Pass),
    }
}

fn parse_txt_status(path: &PathBuf) -> Result<GateStatus> {
    let s = std::fs::read_to_string(path).with_context(|| format!("read {}", path.display()))?;
    if s.to_uppercase().contains("FAIL") {
        Ok(GateStatus::Fail)
    } else {
        Ok(GateStatus::Pass)
    }
}

#[derive(Deserialize)]
struct ResultJson {
    result: String,
}

fn parse_json_result(path: &PathBuf) -> Result<GateStatus> {
    let s = std::fs::read_to_string(path).with_context(|| format!("read {}", path.display()))?;
    let r: ResultJson = serde_json::from_str(&s).with_context(|| format!("parse {}", path.display()))?;
    if r.result.to_uppercase() == "FAIL" {
        Ok(GateStatus::Fail)
    } else {
        Ok(GateStatus::Pass)
    }
}
